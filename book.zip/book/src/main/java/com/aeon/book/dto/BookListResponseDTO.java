package com.aeon.book.dto;

import java.io.Serializable;
import java.util.List;

import com.aeon.book.model.Book;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class BookListResponseDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private List<Book> books;

}
