package com.aeon.book.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "BOOK" , uniqueConstraints = @UniqueConstraint( 
		columnNames = {"isbn" ,"copyNo"}))
public class Book {
	
	@Id
	@Column
	private String id;
	@Column
	private String isbn;
	@Column
	private String copyNo;
	@Column
	private String title;
	@Column
	private String author;

}
