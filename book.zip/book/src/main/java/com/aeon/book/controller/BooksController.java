package com.aeon.book.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aeon.book.dto.BookListResponseDTO;
import com.aeon.book.dto.BookRequestDTO;
import com.aeon.book.dto.BorrowerRegisterDTO;
import com.aeon.book.service.LibraryService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("v1/")
@Slf4j
public class BooksController {
	
	@Autowired
	LibraryService bookService;
	
	@GetMapping("/listAllBooks")
	public ResponseEntity<BookListResponseDTO> listAllBooks() {
		log.info("List All Books");
		return ResponseEntity.ok()
				.body(bookService.getAllBooks());
	}
	
	@PostMapping("/registerBorrower")
	public void registerBorrower(@RequestBody BorrowerRegisterDTO registerDTO) {
		log.info("Register New Borrower");
		bookService.registerBorrower(registerDTO);
	}
	
	@PostMapping("/registerBook")
	public void registerBorrower(@RequestBody BookRequestDTO requestDTO) {
		log.info("Register New Book");
		bookService.registerBook(requestDTO);
	}

}
