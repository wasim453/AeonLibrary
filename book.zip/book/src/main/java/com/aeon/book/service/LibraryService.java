package com.aeon.book.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aeon.book.dto.BookListResponseDTO;
import com.aeon.book.dto.BookRequestDTO;
import com.aeon.book.dto.BorrowerRegisterDTO;
import com.aeon.book.model.Book;
import com.aeon.book.model.Borrower;
import com.aeon.book.repository.BookRepository;
import com.aeon.book.repository.BorrowerRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LibraryService {
	
	@Autowired
	BookRepository bookRepository;
	
	@Autowired
	BorrowerRepository borrowerRepository;
	
	public BookListResponseDTO getAllBooks() {
		List<Book> books= bookRepository.findAll();
		BookListResponseDTO responseDTO = new BookListResponseDTO();
		responseDTO.setBooks(books);
		return responseDTO;
	}
	
	public void registerBook(BookRequestDTO requestDTO) {
		Optional<Book> existing = bookRepository.findByIsbn(requestDTO.getIsbn());
        // We can handle that logic in Postgres Partial Index as well.
	    if (existing.isPresent()) {
	        Book existingBook = existing.get();
	        if (!existingBook.getTitle().equals(requestDTO.getTitle()) &&
	            !existingBook.getAuthor().equals(requestDTO.getAuthor())) {
	            throw new IllegalArgumentException("Same ISBN must have same title and author");
	        }
	    }
		Book book= new Book(requestDTO.getId() , requestDTO.getIsbn(),requestDTO.getCopyNo() 
				, requestDTO.getTitle(), requestDTO.getAuthor());
		
		bookRepository.save(book);
		
	}
	
	public void registerBorrower(BorrowerRegisterDTO registerDTO) {
		Borrower borrower= new Borrower(registerDTO.getId() , 
				registerDTO.getName() , registerDTO.getEmail());
		
		borrowerRepository.save(borrower);
		
	}

}
