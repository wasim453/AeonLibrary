package com.aeon.book.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "BORROWER")
public class Borrower {
	
	@Id
	@Column
	private String id;
	@Column
	private String name;
	@Column
	private String email;

}
